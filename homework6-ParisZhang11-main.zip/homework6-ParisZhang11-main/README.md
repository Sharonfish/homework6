# sp22-assignment6
After each new post/comment, the user needs to refresh the page to display the submitted content
